import TimeUtils from "../utils/TimeUtils";
import LoggerClass from "../utils/LoggerUtils";
import DebugUtils from "../utils/DebugUtils";

export interface TrustConfig {
  maxFailedAttempts: number;
  maxActions: number;
  maxRequests: number;
  timeWindow: string; // String format for duration, e.g., "1h", "30m"
  blockDuration: string; // String format for duration, e.g., "1h", "30m"
}

/**
 * CheckTrustManager is responsible for evaluating the trustworthiness of users based on their behavior
 * and activity within a specified time window. It tracks failed login attempts, user actions,
 * request times, and maintains a list of suspicious IP addresses.
 *
 * @author David Rullán - https://github.com/drullandev
 * @date Agoust 31, 2024
 */
class CheckTrustManager {
  private failedAttempts: number = 0;
  private userActions: number[] = [];
  private requestTimes: number[] = [];
  private suspiciousIPs: string[] = [];
  private blockedIPs: { [key: string]: number } = {};
  private maxFailedAttempts: number;
  private maxActions: number;
  private maxRequests: number;
  private timeWindow: number;
  private blockDuration: number;
  private logger: LoggerClass;
  private debug: boolean;

  /**
   * Constructor to initialize the CheckTrustManager with specific limits for failed attempts,
   * user actions, requests, the time window, and block duration.
   *
   * @param config - Configuration object containing limits and durations.
   */
  constructor(config: TrustConfig) {
    this.debug = DebugUtils.setDebug(false);
    this.logger = LoggerClass.getInstance(this.constructor.name, this.debug, 100);
    
    this.maxFailedAttempts = config.maxFailedAttempts;
    this.maxActions = config.maxActions;
    this.maxRequests = config.maxRequests;
    this.timeWindow = TimeUtils.parseTime(config.timeWindow);
    this.blockDuration = TimeUtils.parseTime(config.blockDuration);
    
    this.logger.info("CheckTrustManager initialized", config);
  }

  /**
   * Records a failed login attempt by incrementing the failed attempts counter.
   */
  public recordFailedAttempt(): void {
    this.failedAttempts++;
    this.logger.warn("Failed attempt recorded", { failedAttempts: this.failedAttempts });
  }

  /**
   * Resets the failed attempts counter to zero.
   */
  public resetFailedAttempts(): void {
    this.failedAttempts = 0;
    this.logger.info("Failed attempts reset");
  }

  /**
   * Records a user action by capturing the current timestamp and filtering out old actions
   * that fall outside the time window.
   */
  public recordUserAction(): void {
    const now = Date.now();
    this.userActions.push(now);
    this.userActions = this.userActions.filter(
      (timestamp) => now - timestamp <= this.timeWindow
    );
    this.logger.debug("User action recorded", { userActions: this.userActions });
  }

  /**
   * Records a request by capturing the current timestamp and filtering out old requests
   * that fall outside the time window.
   */
  public recordRequest(): void {
    const now = Date.now();
    this.requestTimes.push(now);
    this.requestTimes = this.requestTimes.filter(
      (timestamp) => now - timestamp <= this.timeWindow
    );
    this.logger.debug("Request recorded", { requestTimes: this.requestTimes });
  }

  /**
   * Evaluates the trustworthiness of the user based on recorded activity.
   * If the IP is blocked, the trust score is automatically set to 0.
   *
   * @param ip - The IP address of the user to evaluate.
   * @returns The calculated trust score (0 to 10).
   */
  public getTrustScore(ip: string): number {
    if (this.isBlocked(ip)) {
      this.logger.warn(`IP address ${ip} is blocked, trust score set to 0`);
      return 0;
    }

    let score = 10;

    if (this.failedAttempts >= this.maxFailedAttempts) {
      score -= 5;
    }

    if (this.userActions.length >= this.maxActions) {
      score -= 3;
    }

    if (this.isSuspiciousIP(ip)) {
      score -= 4;
    }

    if (this.requestTimes.length > this.maxRequests) {
      score -= 2;
    }

    if (score <= 0) {
      this.blockIP(ip);
      this.logger.warn(`IP address ${ip} blocked due to low trust score`);
      return 0;
    }

    this.logger.info(`Trust score calculated for IP ${ip}: ${score}`);
    return Math.max(0, Math.min(10, score));
  }

  /**
   * Adds an IP address to the list of suspicious IPs.
   *
   * @param ip - The IP address to be marked as suspicious.
   */
  public addSuspiciousIP(ip: string): void {
    if (!this.suspiciousIPs.includes(ip)) {
      this.suspiciousIPs.push(ip);
      this.logger.warn(`IP address ${ip} added to suspicious list`);
      // TODO: Save to database
    }
  }

  /**
   * Blocks an IP address for the duration specified by blockDuration.
   *
   * @param ip - The IP address to block.
   */
  private blockIP(ip: string): void {
    const unblockTime = Date.now() + this.blockDuration;
    this.blockedIPs[ip] = unblockTime;
    this.logger.warn(`IP address ${ip} blocked until ${new Date(unblockTime).toISOString()}`);
  }

  /**
   * Checks if the provided IP address is in the list of suspicious IPs.
   *
   * @param ip - The IP address to check.
   * @returns True if the IP address is suspicious, false otherwise.
   */
  public isSuspiciousIP(ip: string): boolean {
    const isSuspicious = this.suspiciousIPs.includes(ip);
    this.logger.debug(`IP address ${ip} checked: ${isSuspicious ? "Suspicious" : "Not Suspicious"}`);
    return isSuspicious;
  }

  /**
   * Checks if the provided IP address is blocked.
   * If the block period has expired, the IP is unblocked automatically.
   *
   * @param ip - The IP address to check.
   * @returns True if the IP address is blocked, false otherwise.
   */
  public isBlocked(ip: string): boolean {
    const unblockTime = this.blockedIPs[ip];

    if (unblockTime && Date.now() > unblockTime) {
      delete this.blockedIPs[ip]; // Automatically unblock after the block duration has passed
      this.logger.info(`IP address ${ip} unblocked after block duration`);
      return false;
    }

    const isBlocked = unblockTime !== undefined;
    this.logger.debug(`IP address ${ip} blocked status: ${isBlocked}`);
    return isBlocked;
  }

  /**
   * Handles the user action, updates trust status, and logs activity.
   *
   * @param ip - The IP address of the user.
   * @param success - Indicates if the action was successful or not.
   * @returns {boolean} - True if the CAPTCHA should be shown, false otherwise.
   */
  public handleUserAction(ip: string, success: boolean): boolean {
    this.logger.debug("Handling user action", { ip, success });

    if (!success) {
      this.recordFailedAttempt();
    } else {
      this.resetFailedAttempts();
    }

    this.recordUserAction();
    this.recordRequest();

    // Check if the IP should be blocked after this action
    const showCaptcha = this.getTrustScore(ip) < 5;
    this.logger.info(`CAPTCHA decision for IP ${ip}: ${showCaptcha ? "Show" : "Don't Show"}`);
    return showCaptcha;
  }
}

export default CheckTrustManager;
