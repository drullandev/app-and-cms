import LoggerClass from "../utils/LoggerUtils";
import DebugUtils from "../utils/DebugUtils";

/**
 * CheckTrustManager is responsible for evaluating the trustworthiness of users based on their behavior 
 * and activity within a specified time window. It keeps track of failed login attempts, user actions, 
 * request times, and maintains a list of suspicious IP addresses.
 */
class CheckTrustManager {
    private static instance: CheckTrustManager | null = null; // Singleton instance

    private failedAttempts: number = 0; // Count of failed login attempts
    private userActions: number[] = []; // Timestamps of user actions
    private requestTimes: number[] = []; // Timestamps of requests made
    private suspiciousIPs: string[] = []; // List of suspicious IP addresses
    private blockedIPs: { [key: string]: number } = {}; // Dictionary of blocked IPs with unblock timestamp
    private maxFailedAttempts: number; // Maximum allowed failed attempts
    private maxActions: number; // Maximum allowed user actions
    private maxRequests: number; // Maximum allowed requests in the time window
    private timeWindow: number; // Time window in milliseconds for tracking actions
    private blocked = false;
    private blockDuration: number; // Default block duration in milliseconds
    private logger: LoggerClass; // Logger instance
    private debug: boolean; // Debug flag

    /**
     * Constructor to initialize the CheckTrustManager with specific limits for failed attempts, 
     * user actions, requests, the time window, and block duration.
     * 
     * @param maxFailedAttempts - Maximum number of failed login attempts allowed.
     * @param maxActions - Maximum number of actions allowed within the time window.
     * @param maxRequests - Maximum number of requests allowed within the time window.
     * @param timeWindow - Time window in milliseconds for tracking user actions.
     * @param blockDuration - Duration in milliseconds for blocking IPs.
     */
    private constructor(
        maxFailedAttempts = 3,
        maxActions = 20,
        maxRequests = 60,
        timeWindow = 60000,
        blockDuration = 31536000000
    ) {
        this.maxFailedAttempts = maxFailedAttempts;
        this.maxActions = maxActions;
        this.maxRequests = maxRequests;
        this.timeWindow = timeWindow; 
        this.blockDuration = blockDuration;

        // Set debug mode and initialize logger
        this.debug = DebugUtils.setDebug(true); // Adjust as needed
        this.logger = LoggerClass.getInstance(this.constructor.name, this.debug, 100);

        if (this.debug) {
            this.logger.info("CheckTrustManager initialized", {
                maxFailedAttempts,
                maxActions,
                maxRequests,
                timeWindow,
                blockDuration
            });
        }
    }

    /**
     * Get the singleton instance of CheckTrustManager.
     * 
     * @returns The singleton instance of CheckTrustManager.
     */
    public static getInstance(): CheckTrustManager {
        if (this.instance === null) {
            this.instance = new CheckTrustManager();
        }
        return this.instance;
    }

    /** 
     * Records a failed login attempt by incrementing the failed attempts counter.
     */
    private recordFailedAttempt() {
        this.failedAttempts++;
        if (this.debug) {
            this.logger.info("Failed login attempt recorded", { failedAttempts: this.failedAttempts });
        }
    }

    /** 
     * Resets the failed attempts counter to zero.
     */
    private resetFailedAttempts() {
        this.failedAttempts = 0;
        if (this.debug) {
            this.logger.info("Failed attempts counter reset");
        }
    }

    /** 
     * Records a user action by capturing the current timestamp and filtering out old actions 
     * that fall outside the time window.
     */
    private recordUserAction() {
        const now = Date.now();
        this.userActions.push(now);
        this.userActions = this.userActions.filter(timestamp => now - timestamp <= this.timeWindow);

        if (this.debug) {
            this.logger.info("User action recorded", { timestamp: now });
        }
    }

    /** 
     * Records a request by capturing the current timestamp and filtering out old requests 
     * that fall outside the time window.
     */
    private recordRequest() {
        const now = Date.now();
        this.requestTimes.push(now);
        this.requestTimes = this.requestTimes.filter(timestamp => now - timestamp <= this.timeWindow);

        if (this.debug) {
            this.logger.info("Request recorded", { timestamp: now });
        }
    }

    /** 
     * Checks if the provided IP address is in the list of suspicious IPs.
     * 
     * @param ip - The IP address to check.
     * @returns boolean - True if the IP address is suspicious, false otherwise.
     */
    private checkIPAddress(ip: string): boolean {
        const isSuspicious = this.suspiciousIPs.includes(ip);
        if (this.debug) {
            this.logger.info("IP address check", { ip, isSuspicious });
        }
        return isSuspicious;
    }
        
    /** 
     * Retrieves the trust score for a given IP address based on various factors.
     * 
     * @param ip - The IP address to evaluate.
     * @returns number - The calculated trust score.
     */
    public getTrustScore(ip: string): number {
        let score = 10; // Start with maximum score

        if (this.failedAttempts >= this.maxFailedAttempts) {
            score -= 5;
        }

        if (this.userActions.length >= this.maxActions) {
            score -= 3;
        }

        if (this.checkIPAddress(ip)) {
            score -= 4;
        }

        if (this.requestTimes.length > this.maxRequests) {
            score -= 2;
        }

        if (score == 0) {
            this.blocked = true;
        }

        const finalScore = Math.max(0, Math.min(10, score));
        if (this.debug) {
            this.logger.info("Trust score calculated", { ip, score: finalScore });
        }
        return finalScore;
    }

    /** 
     * Handles user actions, records failed attempts if necessary, and updates action and request timestamps.
     * 
     * @param ip - The IP address of the user.
     * @param success - Indicates if the action was successful.
     */
    public handleUserAction(ip: string, success: boolean): void {
        if (!success) {
            this.recordFailedAttempt();
        } else {
            this.resetFailedAttempts();
        }

        this.recordUserAction();
        this.recordRequest();
    }

    /** 
     * Adds an IP address to the list of suspicious IPs.
     * 
     * @param ip - The IP address to add.
     */
    public addSuspiciousIP(ip: string): void {
        if (!this.suspiciousIPs.includes(ip)) {
            this.suspiciousIPs.push(ip);
            if (this.debug) {
                this.logger.info("Suspicious IP added", { ip });
            }
            // TODO: Save to database
        }
    }

    /** 
     * Removes an IP address from the list of suspicious IPs.
     * 
     * @param ip - The IP address to remove.
     */
    public removeSuspiciousIP(ip: string): void {
        this.suspiciousIPs = this.suspiciousIPs.filter(suspiciousIP => suspiciousIP !== ip);
        if (this.debug) {
            this.logger.info("Suspicious IP removed", { ip });
        }
    }

    /** 
     * Displays the trust status of a given IP address.
     * 
     * @param ip - The IP address to evaluate.
     */
    public displayTrustStatus(ip: string): void {
        const trustScore = this.getTrustScore(ip);
        console.log(`El usuario tiene un puntaje de confianza de: ${trustScore}`);
        if (this.debug) {
            this.logger.info("Trust status displayed", { ip, trustScore });
        }
    }

    /** 
     * Checks if an IP address is currently blocked.
     * 
     * @param ip - The IP address to check.
     * @returns boolean - True if the IP is blocked, false otherwise.
     */
    public isBlocked(ip: string): boolean {
        const isBlocked = this.blockedIPs[ip] !== undefined;
        if (this.debug) {
            this.logger.info("Block status checked", { ip, isBlocked });
        }
        return isBlocked;
    }
}

export default CheckTrustManager;
