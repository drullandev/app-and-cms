import RestManager, { CallProps } from '../managers/RestManager';

export interface RestManagerInterface {
  makeAsyncCall(call: CallProps): Promise<void>;
  makeCall(call: CallProps): Promise<void>;
}

const API_BASE_URL = process.env.API_URL || 'https://api.example.com/'; // Mejor práctica para la URL base

// Especificar el tipo usando la interfaz
const mainRest: RestManagerInterface = RestManager.getInstance(API_BASE_URL, {
  'Authorization': 'Bearer your-oauth-token'
});

export default mainRest;