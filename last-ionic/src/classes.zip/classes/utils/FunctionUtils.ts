/**
 * Utility class for handling common operations related to functions,
 * such as debouncing, throttling, and delaying execution.
 *
 * This class centralizes utilities that manipulate functions for better code reuse.
 *
 * @author David Rullán
 * @date September 5, 2024
 */
class FunctionUtils {
  private static instance: FunctionUtils | null = null;
  private timer: ReturnType<typeof setTimeout> | null = null;

  /**
   * Returns the singleton instance of FunctionUtils.
   * If no instance exists, it creates one.
   *
   * @returns The singleton instance of FunctionUtils.
   */
  public static getInstance(): FunctionUtils {
    if (!this.instance) {
      this.instance = new this();
    }
    return this.instance;
  }

  /**
   * Debounce function: ensures a function is called only after a certain amount of time
   * has passed since the last call. Useful to prevent functions from being called too frequently.
   *
   * @param callback The function to debounce.
   * @param delay The debounce delay in milliseconds.
   * @returns A debounced version of the function.
   */
  public debounce<T extends (...args: any[]) => void>(
    callback: T,
    delay: number
  ): T {
    return ((...args: Parameters<T>): void => {
      if (this.timer) {
        clearTimeout(this.timer);
      }
      this.timer = setTimeout(() => callback(...args), delay);
    }) as T;
  }

  /**
   * Throttle function: ensures a function is called at most once in a given period of time.
   * This is useful for rate-limiting functions that are triggered too frequently.
   *
   * @param callback The function to throttle.
   * @param limit The time limit in milliseconds.
   * @returns A throttled version of the function.
   */
  public throttle<T extends (...args: any[]) => void>(
    callback: T,
    limit: number
  ): T {
    let lastCall = 0;
    return ((...args: Parameters<T>): void => {
      const now = Date.now();
      if (now - lastCall >= limit) {
        lastCall = now;
        callback(...args);
      }
    }) as T;
  }

  /**
   * Delays the execution of a function by a specified time.
   *
   * @param callback The function to delay.
   * @param delay The delay in milliseconds.
   * @returns A promise that resolves after the delay.
   */
  public delay<T extends (...args: any[]) => void>(
    callback: T,
    delay: number
  ): Promise<void> {
    return new Promise((resolve) => {
      setTimeout(() => {
        callback();
        resolve();
      }, delay);
    });
  }

  /**
   * Cancels any active timeout for debounce or delay.
   * This can be used to clear pending debounced or delayed function executions.
   */
  public clear() {
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
  }
}

export default FunctionUtils.getInstance();
