export interface ToastProps {
  message?: string
  color?: string
  show: boolean
  duration?: number
  type?: string
  timestamp?: number
  icon?: any
}