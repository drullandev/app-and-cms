export interface SplashProps {
  show: boolean
  splash: any
  setShowSplash: any
  timeout: number
}