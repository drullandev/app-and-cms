# Refresher

## Description
undefined

## API
- **Props**: <IonRefresher onRefresh={() => { /* Refresh logic */ }} />

## Example
<IonRefresher onRefresh={() => { /* Refresh logic */ }} />

## Documentation URL
https://ionicframework.com/docs/api/refresher
