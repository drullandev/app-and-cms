// This file has been automatically generated
// by the component generation script.
import { IonRefresher } from '@ionic/react';

export type IonRefresherProps = React.ComponentProps<typeof IonRefresher> & {
    ariaLabel?: any;
    ononrefresh?: (e: any) => void;
};
