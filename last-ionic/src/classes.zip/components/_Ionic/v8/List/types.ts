// This file has been automatically generated
// by the component generation script.
import { IonList } from '@ionic/react';

export type IonListProps = React.ComponentProps<typeof IonList> & {
    ariaLabel?: any;

};
