# List

## Description
undefined

## API
- **Props**: <IonList><IonItem>Item 1</IonItem><IonItem>Item 2</IonItem></IonList>

## Example
<IonList><IonItem>Item 1</IonItem><IonItem>Item 2</IonItem></IonList>

## Documentation URL
https://ionicframework.com/docs/api/list
