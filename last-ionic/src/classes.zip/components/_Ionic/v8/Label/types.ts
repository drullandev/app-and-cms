// This file has been automatically generated
// by the component generation script.
import { IonLabel } from '@ionic/react';

export type IonLabelProps = React.ComponentProps<typeof IonLabel> & {
    ariaLabel?: any;

};
