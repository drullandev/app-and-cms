# Label

## Description
undefined

## API
- **Props**: <IonLabel>Label text</IonLabel>

## Example
<IonLabel>Label text</IonLabel>

## Documentation URL
https://ionicframework.com/docs/api/label
