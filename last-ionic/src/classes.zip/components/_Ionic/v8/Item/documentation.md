# Item

## Description
undefined

## API
- **Props**: <IonItem>Item content</IonItem>

## Example
<IonItem>Item content</IonItem>

## Documentation URL
https://ionicframework.com/docs/api/item
