// This file has been automatically generated
// by the component generation script.
import { IonItem } from '@ionic/react';

export type IonItemProps = React.ComponentProps<typeof IonItem> & {
    ariaLabel?: any;
    ononclick?: (e: any) => void;
};
