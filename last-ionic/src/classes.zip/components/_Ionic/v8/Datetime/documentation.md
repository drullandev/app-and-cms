# Datetime

## Description
undefined

## API
- **Props**: <IonDatetime aria-label='Select date and time' />

## Example
<IonDatetime aria-label='Select date and time' />

## Documentation URL
https://ionicframework.com/docs/api/datetime
