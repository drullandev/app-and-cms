// This file has been automatically generated
// by the component generation script.
import { IonDatetime } from '@ionic/react';

export type IonDatetimeProps = React.ComponentProps<typeof IonDatetime> & {
    ariaLabel: any;
    ononchange?: (e: any) => void;
};
