# Badge

## Description
undefined

## API
- **Props**: <IonBadge>New</IonBadge>

## Example
<IonBadge>New</IonBadge>

## Documentation URL
https://ionicframework.com/docs/api/badge
