// This file has been automatically generated
// by the component generation script.
import { IonBadge } from '@ionic/react';

export type IonBadgeProps = React.ComponentProps<typeof IonBadge> & {
    ariaLabel?: any;

};
