// This file has been automatically generated
// by the component generation script.
import { IonPopover } from '@ionic/react';

export type IonPopoverProps = React.ComponentProps<typeof IonPopover> & {
    ariaLabel: any;
    onondiddismiss?: (e: any) => void;
};
