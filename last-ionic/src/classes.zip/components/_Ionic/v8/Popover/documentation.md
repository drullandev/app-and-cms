# Popover

## Description
undefined

## API
- **Props**: const popover = await popoverController.create({ component: 'YourComponent', translucent: true }); await popover.present();

## Example
const popover = await popoverController.create({ component: 'YourComponent', translucent: true }); await popover.present();

## Documentation URL
https://ionicframework.com/docs/api/popover
