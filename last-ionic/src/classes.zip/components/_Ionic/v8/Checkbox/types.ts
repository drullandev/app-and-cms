// This file has been automatically generated
// by the component generation script.
import { IonCheckbox } from '@ionic/react';

export type IonCheckboxProps = React.ComponentProps<typeof IonCheckbox> & {
    ariaChecked?: any;
    ariaLabel: any;
    ononchange?: (e: any) => void;
};
