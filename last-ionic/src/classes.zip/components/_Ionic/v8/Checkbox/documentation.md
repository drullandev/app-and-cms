# Checkbox

## Description
undefined

## API
- **Props**: <IonCheckbox aria-label='Check me' />

## Example
<IonCheckbox aria-label='Check me' />

## Documentation URL
https://ionicframework.com/docs/api/checkbox
