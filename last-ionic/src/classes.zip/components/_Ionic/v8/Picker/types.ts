// This file has been automatically generated
// by the component generation script.
import { IonPicker } from '@ionic/react';

export type IonPickerProps = React.ComponentProps<typeof IonPicker> & {
    ariaLabel: any;
    ononchange?: (e: any) => void;
};
