# Picker

## Description
undefined

## API
- **Props**: const picker = await pickerController.create({ columns: [...], buttons: [...] }); await picker.present();

## Example
const picker = await pickerController.create({ columns: [...], buttons: [...] }); await picker.present();

## Documentation URL
https://ionicframework.com/docs/api/picker
