// This file has been automatically generated
// by the component generation script.
import { IonImg } from '@ionic/react';

export type IonImgProps = React.ComponentProps<typeof IonImg> & {
    alt: any;
    ariaLabel?: any;

};
