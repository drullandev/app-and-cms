# Img

## Description
undefined

## API
- **Props**: <IonImg src='image.jpg' alt='An image' />

## Example
<IonImg src='image.jpg' alt='An image' />

## Documentation URL
https://ionicframework.com/docs/api/img
