// This file has been automatically generated
// by the component generation script.
import { IonRadio } from '@ionic/react';

export type IonRadioProps = React.ComponentProps<typeof IonRadio> & {
    ariaChecked?: any;
    ariaLabel: any;
    ononchange?: (e: any) => void;
};
