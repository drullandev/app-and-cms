# Radio

## Description
undefined

## API
- **Props**: <IonRadio aria-label='Option 1' />

## Example
<IonRadio aria-label='Option 1' />

## Documentation URL
https://ionicframework.com/docs/api/radio
