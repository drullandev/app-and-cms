// This file has been automatically generated
// by the component generation script.
import { IonCard } from '@ionic/react';

export type IonCardProps = React.ComponentProps<typeof IonCard> & {
    ariaLabel?: any;

};
