# Card

## Description
undefined

## API
- **Props**: <IonCard><IonCardContent>Content</IonCardContent></IonCard>

## Example
<IonCard><IonCardContent>Content</IonCardContent></IonCard>

## Documentation URL
https://ionicframework.com/docs/api/card
