# Segment

## Description
undefined

## API
- **Props**: <IonSegment><IonSegmentButton>Option 1</IonSegmentButton><IonSegmentButton>Option 2</IonSegmentButton></IonSegment>

## Example
<IonSegment><IonSegmentButton>Option 1</IonSegmentButton><IonSegmentButton>Option 2</IonSegmentButton></IonSegment>

## Documentation URL
https://ionicframework.com/docs/api/segment
