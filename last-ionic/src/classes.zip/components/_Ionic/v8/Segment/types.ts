// This file has been automatically generated
// by the component generation script.
import { IonSegment } from '@ionic/react';

export type IonSegmentProps = React.ComponentProps<typeof IonSegment> & {
    ariaLabel?: any;
    ononionchange?: (e: any) => void;
};
