// This file has been automatically generated
// by the component generation script.
import { IonButtons } from '@ionic/react';

export type IonButtonsProps = React.ComponentProps<typeof IonButtons> & {


};
