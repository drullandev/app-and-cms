# Buttons

## Description
undefined

## API
- **Props**: <IonButtons><IonButton>Button 1</IonButton><IonButton>Button 2</IonButton></IonButtons>

## Example
<IonButtons><IonButton>Button 1</IonButton><IonButton>Button 2</IonButton></IonButtons>

## Documentation URL
https://ionicframework.com/docs/api/buttons
