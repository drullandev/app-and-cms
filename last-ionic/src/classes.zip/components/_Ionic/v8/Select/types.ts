// This file has been automatically generated
// by the component generation script.
import { IonSelect } from '@ionic/react';

export type IonSelectProps = React.ComponentProps<typeof IonSelect> & {
    ariaLabel: any;
    ononionchange?: (e: any) => void;
};
