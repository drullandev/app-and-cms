# Select

## Description
undefined

## API
- **Props**: <IonSelect aria-label='Choose an option' />

## Example
<IonSelect aria-label='Choose an option' />

## Documentation URL
https://ionicframework.com/docs/api/select
