// This file has been automatically generated
// by the component generation script.
import { IonLoading } from '@ionic/react';

export type IonLoadingProps = React.ComponentProps<typeof IonLoading> & {
    ariaLabel?: any;

};
