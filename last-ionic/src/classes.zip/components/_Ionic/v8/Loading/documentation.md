# Loading

## Description
undefined

## API
- **Props**: <IonLoading isOpen={true} message='Loading...' />

## Example
<IonLoading isOpen={true} message='Loading...' />

## Documentation URL
https://ionicframework.com/docs/api/loading
