# ActionSheet

## Description
undefined

## API
- **Props**: <IonActionSheet buttons={buttons} />

## Example
<IonActionSheet buttons={buttons} />

## Documentation URL
https://ionicframework.com/docs/api/action-sheet
