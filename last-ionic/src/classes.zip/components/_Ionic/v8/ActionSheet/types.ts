// This file has been automatically generated
// by the component generation script.
import { IonActionSheet } from '@ionic/react';

export type IonActionSheetProps = React.ComponentProps<typeof IonActionSheet> & {
    ariaLabel: any;
    ononionwilldismiss?: (e: any) => void;
    ononiondiddismiss?: (e: any) => void;
};
