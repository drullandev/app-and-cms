# Alert

## Description
undefined

## API
- **Props**: <IonAlert header='Alert' message='This is an alert' />

## Example
<IonAlert header='Alert' message='This is an alert' />

## Documentation URL
https://ionicframework.com/docs/api/alert
