// This file has been automatically generated
// by the component generation script.
import { IonAlert } from '@ionic/react';

export type IonAlertProps = React.ComponentProps<typeof IonAlert> & {
    ariaLabel: any;
    ononionwilldismiss?: (e: any) => void;
    ononiondiddismiss?: (e: any) => void;
};
