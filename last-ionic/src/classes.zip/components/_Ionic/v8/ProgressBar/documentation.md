# ProgressBar

## Description
undefined

## API
- **Props**: <IonProgressBar value={50} />

## Example
<IonProgressBar value={50} />

## Documentation URL
https://ionicframework.com/docs/api/progress-bar
