// This file has been automatically generated
// by the component generation script.
import { IonProgressBar } from '@ionic/react';

export type IonProgressBarProps = React.ComponentProps<typeof IonProgressBar> & {
    ariaLabel?: any;
    ariaValuemax?: any;
    ariaValuemin?: any;
    ariaValuenow: any;

};
