// This file has been automatically generated
// by the component generation script.
import { IonIcon } from '@ionic/react';

export type IonIconProps = React.ComponentProps<typeof IonIcon> & {
    ariaLabel?: any;

};
