# Icon

## Description
undefined

## API
- **Props**: <IonIcon name='star' />

## Example
<IonIcon name='star' />

## Documentation URL
https://ionicframework.com/docs/api/icon
