# Modal

## Description
undefined

## API
- **Props**: <IonModal isOpen={true}>Modal content</IonModal>

## Example
<IonModal isOpen={true}>Modal content</IonModal>

## Documentation URL
https://ionicframework.com/docs/api/modal
