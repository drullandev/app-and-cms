// This file has been automatically generated
// by the component generation script.
import { IonModal } from '@ionic/react';

export type IonModalProps = React.ComponentProps<typeof IonModal> & {
    ariaLabel?: any;
    onondiddismiss?: (e: any) => void;
};
