# Searchbar

## Description
undefined

## API
- **Props**: <IonSearchbar aria-label='Search' />

## Example
<IonSearchbar aria-label='Search' />

## Documentation URL
https://ionicframework.com/docs/api/searchbar
