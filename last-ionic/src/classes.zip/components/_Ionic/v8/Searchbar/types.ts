// This file has been automatically generated
// by the component generation script.
import { IonSearchbar } from '@ionic/react';

export type IonSearchbarProps = React.ComponentProps<typeof IonSearchbar> & {
    ariaLabel: any;
    ononinput?: (e: any) => void;
    ononsearch?: (e: any) => void;
};
