// This file has been automatically generated
// by the component generation script.
import { IonMenu } from '@ionic/react';

export type IonMenuProps = React.ComponentProps<typeof IonMenu> & {
    ariaLabel?: any;
    ononopen?: (e: any) => void;
    ononclose?: (e: any) => void;
};
