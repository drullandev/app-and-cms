# Menu

## Description
undefined

## API
- **Props**: <IonMenu><IonContent>Menu content</IonContent></IonMenu>

## Example
<IonMenu><IonContent>Menu content</IonContent></IonMenu>

## Documentation URL
https://ionicframework.com/docs/api/menu
