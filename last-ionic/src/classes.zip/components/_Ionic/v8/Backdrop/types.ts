// This file has been automatically generated
// by the component generation script.
import { IonBackdrop } from '@ionic/react';

export type IonBackdropProps = React.ComponentProps<typeof IonBackdrop> & {
    ariaHidden?: any;

};
