# Backdrop

## Description
undefined

## API
- **Props**: <IonBackdrop />

## Example
<IonBackdrop />

## Documentation URL
https://ionicframework.com/docs/api/backdrop
