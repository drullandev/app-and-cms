# Button

## Description
undefined

## API
- **Props**: <IonButton>Click me</IonButton>

## Example
<IonButton>Click me</IonButton>

## Documentation URL
https://ionicframework.com/docs/api/button
