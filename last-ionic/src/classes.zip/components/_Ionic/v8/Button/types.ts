// This file has been automatically generated
// by the component generation script.
import { IonButton } from '@ionic/react';

export type IonButtonProps = React.ComponentProps<typeof IonButton> & {
    ariaDisabled?: any;
    ariaLabel: any;
    ononclick?: (e: any) => void;
    ononfocus?: (e: any) => void;
};
