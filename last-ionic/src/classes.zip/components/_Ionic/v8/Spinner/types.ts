// This file has been automatically generated
// by the component generation script.
import { IonSpinner } from '@ionic/react';

export type IonSpinnerProps = React.ComponentProps<typeof IonSpinner> & {
    ariaLabel?: any;

};
