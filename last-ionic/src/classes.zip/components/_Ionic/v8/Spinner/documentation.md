# Spinner

## Description
undefined

## API
- **Props**: <IonSpinner />

## Example
<IonSpinner />

## Documentation URL
https://ionicframework.com/docs/api/spinner
