# SkeletonText

## Description
undefined

## API
- **Props**: <IonSkeletonText />

## Example
<IonSkeletonText />

## Documentation URL
https://ionicframework.com/docs/api/skeleton-text
