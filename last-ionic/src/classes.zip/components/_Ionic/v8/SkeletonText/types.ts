// This file has been automatically generated
// by the component generation script.
import { IonSkeletonText } from '@ionic/react';

export type IonSkeletonTextProps = React.ComponentProps<typeof IonSkeletonText> & {
    ariaLabel?: any;

};
