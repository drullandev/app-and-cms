# Toggle

## Description
undefined

## API
- **Props**: <IonToggle aria-label='Enable feature' />

## Example
<IonToggle aria-label='Enable feature' />

## Documentation URL
https://ionicframework.com/docs/api/toggle
