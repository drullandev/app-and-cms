// This file has been automatically generated
// by the component generation script.
import { IonToggle } from '@ionic/react';

export type IonToggleProps = React.ComponentProps<typeof IonToggle> & {
    ariaChecked?: any;
    ariaLabel: any;
    ononionchange?: (e: any) => void;
};
