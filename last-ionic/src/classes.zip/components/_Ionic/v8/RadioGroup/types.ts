// This file has been automatically generated
// by the component generation script.
import { IonRadioGroup } from '@ionic/react';

export type IonRadioGroupProps = React.ComponentProps<typeof IonRadioGroup> & {

    ononionchange?: (e: any) => void;
};
