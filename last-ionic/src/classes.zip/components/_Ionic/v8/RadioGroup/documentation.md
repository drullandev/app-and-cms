# RadioGroup

## Description
undefined

## API
- **Props**: <IonRadioGroup><IonRadio value="value1">Option 1</IonRadio><IonRadio value="value2">Option 2</IonRadio></IonRadioGroup>

## Example
<IonRadioGroup><IonRadio value="value1">Option 1</IonRadio><IonRadio value="value2">Option 2</IonRadio></IonRadioGroup>

## Documentation URL
https://ionicframework.com/docs/api/radio-group
