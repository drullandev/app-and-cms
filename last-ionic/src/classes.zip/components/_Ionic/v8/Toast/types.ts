// This file has been automatically generated
// by the component generation script.
import { IonToast } from '@ionic/react';

export type IonToastProps = React.ComponentProps<typeof IonToast> & {


};
