# Toast

## Description
undefined

## API
- **Props**: const toast = await toastController.create({ message: 'Toast message', duration: 2000 }); await toast.present();

## Example
const toast = await toastController.create({ message: 'Toast message', duration: 2000 }); await toast.present();

## Documentation URL
https://ionicframework.com/docs/api/toast-controller
