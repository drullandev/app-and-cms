// This file has been automatically generated
// by the component generation script.
import { IonContent } from '@ionic/react';

export type IonContentProps = React.ComponentProps<typeof IonContent> & {
    ariaLabel?: any;

};
