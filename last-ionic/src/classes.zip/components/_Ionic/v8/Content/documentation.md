# Content

## Description
undefined

## API
- **Props**: <IonContent>Content goes here</IonContent>

## Example
<IonContent>Content goes here</IonContent>

## Documentation URL
https://ionicframework.com/docs/api/content
