// This file has been automatically generated
// by the component generation script.
import { IonFab } from '@ionic/react';

export type IonFabProps = React.ComponentProps<typeof IonFab> & {
    ariaLabel: any;
    ononclick?: (e: any) => void;
};
