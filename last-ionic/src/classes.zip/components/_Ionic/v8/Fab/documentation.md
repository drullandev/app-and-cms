# Fab

## Description
undefined

## API
- **Props**: <IonFab><IonFabButton>+</IonFabButton></IonFab>

## Example
<IonFab><IonFabButton>+</IonFabButton></IonFab>

## Documentation URL
https://ionicframework.com/docs/api/fab
