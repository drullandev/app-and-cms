// This file has been automatically generated
// by the component generation script.
import { IonInput } from '@ionic/react';

export type IonInputProps = React.ComponentProps<typeof IonInput> & {
    ariaLabel: any;
    ariaRequired?: any;
    ononchange?: (e: any) => void;
    ononfocus?: (e: any) => void;
};
