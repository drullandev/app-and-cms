# Input

## Description
undefined

## API
- **Props**: <IonInput aria-label='Enter text' />

## Example
<IonInput aria-label='Enter text' />

## Documentation URL
https://ionicframework.com/docs/api/input
