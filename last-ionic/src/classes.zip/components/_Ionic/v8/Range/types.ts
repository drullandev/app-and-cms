// This file has been automatically generated
// by the component generation script.
import { IonRange } from '@ionic/react';

export type IonRangeProps = React.ComponentProps<typeof IonRange> & {
    ariaLabel: any;
    ariaValuemax: any;
    ariaValuemin: any;
    ariaValuenow: any;
    ononchange?: (e: any) => void;
};
