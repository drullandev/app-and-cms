# Range

## Description
undefined

## API
- **Props**: <IonRange aria-label='Volume' min={0} max={100} step={1} value={50} />

## Example
<IonRange aria-label='Volume' min={0} max={100} step={1} value={50} />

## Documentation URL
https://ionicframework.com/docs/api/range
