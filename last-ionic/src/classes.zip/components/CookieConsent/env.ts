export const COOKIE_CONSENT_KEY = 'cookieConsent'; // Clave para almacenar el consentimiento
export const COOKIE_CONSENT_KEY_EXPIRE = 'cookieConsentExpire'; // Clave para almacenar el consentimiento
export const COOKIE_EXPIRATION_TIME = '12months'; // Tiempo de expiración de la cookie
