import * as AppConst from '../../config/env'
import React from 'react'
// I did it with graphql

interface PopoverProps {
  dismiss: Function
}


const Settings: React.FC<PopoverProps> = ({dismiss}) => {
  return <></>
}

export default Settings