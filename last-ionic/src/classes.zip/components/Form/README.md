TODO: Make this as a module separated with the clases also ^^
