export interface OverlayProps {
    show: boolean;
    duration: number;
}
  