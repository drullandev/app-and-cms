This is the area to set all related with accesibility in Ionic: 

Summary from : https://ionic.io/docs/accessibility/ion-icon


