export interface LogoutProps {
    setData: (data: any) => void;
}
  