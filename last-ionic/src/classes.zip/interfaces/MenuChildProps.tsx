export interface MenuChildProps {
  id: number
  menu?: {
    slug: string
    slot: string
  }
}