export interface HeaderProps {
  label?: any
  slot?: string
  loading?:boolean
}