export interface MenuProps {
  id: number
  //slug: string
  //slot: string
}