export interface Filter {
  key: number
  type: string
  field: string
  action: string
  value: string
}