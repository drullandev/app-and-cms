export interface Page {
    title: string;
    path: string;
    icon: string;
    routerDirection?: string;
}