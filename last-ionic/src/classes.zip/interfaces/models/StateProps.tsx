
export interface StateProps {
  userDarkMode: boolean
  isLoggedIn: boolean
  menuEnabled: boolean
}