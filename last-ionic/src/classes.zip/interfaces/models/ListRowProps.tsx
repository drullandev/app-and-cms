export interface ListRowProps {
  id: number
  title?: string
  name?: string
  path: string
  slot?: string
  icon?: string
}