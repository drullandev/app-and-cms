//import { MenuChildProps } from './MenuChildProps'
export interface MenuCompProps {
  id: number
  name?: string
  title?: string
  slug: string
  position?: string
  //children?: MenuChildProps[]
}
