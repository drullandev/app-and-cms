export interface MapProps {
  userDarkMode: boolean
  isLoggedIn: boolean
  menuEnabled: boolean
}