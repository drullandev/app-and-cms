export interface HeaderProps {
  label?: string
  slot?: string
}