export interface FormDataProps {
  slug: string
}
