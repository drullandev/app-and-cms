export interface TabButtonProps {
  path: {
    slug: string
    value: string
  }
  icon: string
  label: string
}