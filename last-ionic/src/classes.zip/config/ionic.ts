import { setupIonicReact } from '@ionic/react';

// https://ionicframework.com/docs/react/config#global-config
setupIonicReact({
  rippleEffect: true,
  animated: true
});
