// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
export const firebaseConfig = {
  apiKey: "AIzaSyCooDTm5PWXxlTlC4r8YY-_be2dsYL1lTU",
  authDomain: "strapionic.firebaseapp.com",
  projectId: "strapionic",
  storageBucket: "strapionic.appspot.com",
  messagingSenderId: "245833522223",
  appId: "1:245833522223:web:7281c95c4fb93af9cc3ada",
  measurementId: "G-576NRJ1ZTL"
}